#define RX_MODE 4
#define TX_MODE 4
#define TX_TONE 10
#define MUX_HALF 0
