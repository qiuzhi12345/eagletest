#ifndef  I2C_DEFINE_H
#define  I2C_DEFINE_H


#define I2C_RFRX_HOST   1
#define I2C_SDM_HOST    1
#define I2C_BBTOP_HOST  0
#define I2C_PLL_HOST    1
#define I2C_TXRF_HOST   0
#define I2C_BIAS_HOST   0
#define I2C_PLLA_HOST   0
#define I2C_XTAL_HOST   0
#define I2C_ana_dig_HOST   0
#define I2C_CKGEN_HOST  0
#define I2C_BBPLL_HOST  0
#define I2C_ULP_HOST  	0


#define I2C_RFRX_BLOCK   0x64
#define I2C_SDM_BLOCK    0x63
#define I2C_BBTOP_BLOCK  0x67
#define I2C_PLL_BLOCK    0x62
#define I2C_TXRF_BLOCK   0x6b
#define I2C_BIAS_BLOCK   0x6a
#define I2C_PLLA_BLOCK   0x6d
#define I2C_XTAL_BLOCK   0x68
#define I2C_ana_dig_BLOCK   0x7d
#define I2C_CKGEN_BLOCK  0x65
#define I2C_BBPLL_BLOCK  0x66
#define I2C_ULP_BLOCK	 0x61


#endif
