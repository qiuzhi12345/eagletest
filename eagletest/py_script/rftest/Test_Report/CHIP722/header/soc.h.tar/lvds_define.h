#define USE_LVDS_PAD 0

#define CMD_3WIRE_LVDS 0
#define LVDS_CYC12 0
#define LVDS_CYC24 0
